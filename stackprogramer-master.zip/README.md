#In the Name of God

##stackprogramer(R.B)
![stackprogramer](https://avatars3.githubusercontent.com/u/11349841?v=3&s=460 "profile stackprogramer")
```json
   Electronic Engineer 
•	Iran,Fars
•	Shiraz, Fars 
•	stackprogramer@gmail.com 
•	.... 
```
```json
  Summary 	                      Engineer Electronics, Computer
                                      science interested 
```

```json
 Skills: 
##Electronic Branch: 
•	Design electronic circuits and  chips semiconductor   and so on.
•	Pspice/Orcad/Hspice 
•	Altium designer/Protel /PCB
•	ARM/Keil/Atmel studio 
•	SMD soldering 

##Software Branch: 
•	PHP,HTML,CSS,javascript
•	Frameworks bootstrap and jQuery and laravel 
•	CMS joomla 
•	Qt framework,design windows application for android,ios,mac,win and linux 
•	c++11 with GCC,Mingw,Visual Studio  compiler,java ME,SE 
•	image processing,opencv,matlab 
•	Matlab  Gui,Simulink ,Image processing 
•	Linux Ubuntu /terminal /Network Programing 
##Future Objects: 
•	FPGA 
•	Repairman Mobile and PC,laptop
```
 ```json
 
 Education :
##Shiraz university 
    Engineer Electronics 
   Shiraz, Fars 
   Graduated August 2015
   GPA=16.15

   Shiraz university
   Master of Science Electronics
   Shiraz, Fars 
```






```json
  ##Hobbies :
Forums,math study,Rubik's Cube

https://github.com/stackprogramer
https://sourceforge.net/u/stackprogramer/profile/
http://barnamenevis.org/member.php?353093-stackprogramer
http://joomlaforum.ir/member.php/25591-stackprogramer
http://www.eca.ir/forum2/index.php?action=profile
http://opencv.ir/forum/memberlist.php?mode=viewprofile&u=1230
http://www.iranmicro.ir/forum/members/stackprograme/
http://answers.opencv.org/users/20923/stackprogramer/?sort=stats
http://qt-apps.org/usermanager/search.php?username=stackprogramer
http://stackoverflow.com/users/4569486/stack-programer?tab=profile
http://www.tamirkaran.ir/forum/members/stack/
http://forum.gsmhosting.com/vbb/member.php?u=2433202
http://www.mihangsm.com/forum/member.php?u=140273
http://www.iranian-gsm.com/member.php?u=84462
http://forum.mobilestan.net/member.php?u=827080
https://forum.qt.io/user/stackprogramer
http://www.ubuntuforums.ir/members/748-stackprogramer
http://askubuntu.com/users/432721/stackprogramer?tab=profile
http://www.panatel.org/member.php?u=178437
http://forum.elektor.com
https://www.physicsforums.com/members/stackprogramer.572196/
www.ifixit.com/
```






```json
  Developed  Projects :for seeing Developed Projects and more info  go to githubpage.
MypageGithub

Languages: 
	English USA 
Contact:        
                            
stackprogramer(R.B)      Fars,Shiraz
Contact me:      ....
stackprogramer@gmail.com


-----BEGIN PGP MESSAGE-----
Version: GnuPG v2.0.19 (MingW32)

jA0ECQMCqIwUSbIUNWm10ukBVF7YzA1+3a1cmwrYgEV1lUTZk+oUWFsCCwJbkVhW
W+xb0LDVbQx1ERbjoMNl5zFw+8dXDFE+HV8Tey9vn8WQZztxO+LvX8CSdnKbjN8M
qC2a+JNOEU2WJ7WiccJz1SQNE1NpOOPI4dJThRnHSRapUYOJOIeY0RfZDGLq1f2T
FYOUch0EBAIFPdJfQ0UtdDaUDNaaNY3pOP0BaRe1MKhuVywjp5g6DzBwkNDDrZEv
2hOPycbjqoMuhqlOOpSS9LOP5U9RTvvSOn9EP8s5uE73LhBgig1pH52ySgKdGVi0
2kvAZapsws4nJO6bh3I6HS7QyO3evGERuvprvgv//3BeBuncCilY3u9+bBkXLC6A
3iMPTwCc/SPkXTCdmRHBaF6UH+TE+h+Ow5X+3Sq5PNWwHQDMzSzx+OUj8DTIeqHU
w81Pxy0GqqCx8DoEuP1a1Vhb9RjlM9bygmT7g1ALP1iIpF8S0nBVZzmMFSeuA1DY
VO0fQzhDqfYyZq3hGk3tWKkvshrzt6p7XhH53ZSw+UP+/ByhyId01zwIiBupC6Q9
Z27UJW10WtJhU65Bk/vvAOW4erbZFEPYUy5JbScsXhRzmt1i3KowsgxQEO2zm4Py
+52J/U5835ogCjzO0dOY8NqlYXAVtqrU/L1C2KZ/QKY2Q4/b6Z1G8Xt15QmtZZTE
RCw+vw19B9KQlluZPvpW4Iv8ITsUVmah5Dzig5XQ9OLM8IuT/u4XQ66hs52VXg==
=xn9X
-----END PGP MESSAGE-----

                                               The End
```

most active in:

##github
https://github.com/stackprogramer/
##codeproject
http://www.codeproject.com/Members/stackprogramer
##career
http://stackoverflow.com/cv/stackprogramer
##stackoverflow
http://stackoverflow.com/users/4569486/stackprogramer?tab=profile
##Qt
https://forum.qt.io/user/stackprogramer
##edaboard
http://www.edaboard.com/member572004.html
##ifixit
https://www.ifixit.com/User/1459804/stackprogramer
##10fastfingers
http://10fastfingers.com/user/1046235/
###youtube channel:
https://www.youtube.com/channel/UCL5VKj57OkAz09I--2sKxWQ





